# ESP32 Industrial IoT Monitoring Firmware

## Included
- `industrial_iot_monitor.ino`: complete Arduino IDE sketch.
- This system monitors sensors, detects threshold-based faults, displays status, activates alerts, and uploads data to ThingSpeak.
- It does NOT perform automatic recovery or repair.

## Wiring
| Device | ESP32 |
|---|---|
| DHT11 DATA | GPIO 4 |
| INA219 SDA / SCL | GPIO 21 / GPIO 22 |
| MPU6050 SDA / SCL | GPIO 21 / GPIO 22 |
| I2C LCD SDA / SCL | GPIO 21 / GPIO 22 |
| Red LED (with resistor) | GPIO 25 |
| Green LED (with resistor) | GPIO 27 |
| Yellow LED (with resistor) | GPIO 14 |
| Active buzzer signal | GPIO 13 |
| Module grounds | ESP32 GND |

All three I2C devices share the same bus. LCD address is set to `0x27`.

## Arduino IDE libraries
Install:
1. DHT sensor library (Adafruit)
2. Adafruit Unified Sensor
3. Adafruit INA219
4. Adafruit MPU6050
5. LiquidCrystal_I2C (compatible with `init()` and `backlight()`)
6. ThingSpeak

Select the ESP32 Dev Module board and the correct COM port. Open the `.ino` file and upload at 115200 baud Serial Monitor setting.

## Configure before upload
In the sketch, replace:
- `YOUR_WIFI_NAME`
- `YOUR_WIFI_PASSWORD`
- `CHANNEL_ID = 0` with your ThingSpeak channel ID
- `YOUR_WRITE_API_KEY` with your ThingSpeak Write API Key

Create these 8 ThingSpeak fields:
1. Temperature_C
2. Humidity_Percent
3. BusVoltage_V
4. Current_mA
5. Power_mW
6. Vibration_Index
7. Fault_Code
8. Alert_Level

Upload interval is 20 seconds. Adjust example thresholds near the top of the sketch to suit your equipment.

## Fault codes
0 Normal; 1 Warning; 2 High temperature; 3 Overcurrent; 4 High vibration; 5 Sensor fault.
Alert level: 0 Normal, 1 Warning, 2 Critical.

## Important limitations and safety
- The fault checks in this sketch are threshold-based. They are not a trained machine-learning model. A genuine ML model must be trained and run separately (for example, in Python) or converted for deployment on the ESP32.
- The vibration value is a simple acceleration-magnitude deviation from gravity, not calibrated RMS vibration.
- ESP32 GPIO pins are 3.3 V only. Never apply 5 V to GPIO.
- Use 220–330 ohm series resistors for LEDs.
- Use a transistor driver if the buzzer current exceeds safe GPIO limits.
- If the LCD backpack is powered at 5 V, ensure I2C pull-ups do not pull SDA/SCL to 5 V; use 3.3 V-compatible pull-ups or a level shifter.
- Connect INA219 in series with the load supply and stay within the module's voltage/current ratings.
- Test with safe low-voltage equipment before connecting industrial machinery.
