#include <WiFi.h>
#include <Wire.h>
#include <DHT.h>
#include <Adafruit_INA219.h>
#include <Adafruit_MPU6050.h>
#include <Adafruit_Sensor.h>
#include <LiquidCrystal_I2C.h>
#include <ThingSpeak.h>

// Enter your own credentials:
const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
unsigned long CHANNEL_ID = 0;
const char* WRITE_API_KEY = "YOUR_WRITE_API_KEY";

// Pins: DHT11 GPIO4; shared I2C SDA21/SCL22;
// red LED25, green LED27, yellow LED14, active buzzer13.
#define DHT_PIN 4
#define DHT_TYPE DHT11
#define RED_LED 25
#define GREEN_LED 27
#define YELLOW_LED 14
#define BUZZER 13

// Example limits: adjust for your machine after testing.
const float TEMP_WARN = 40.0, TEMP_FAULT = 50.0;
const float CURRENT_WARN_MA = 500.0, CURRENT_FAULT_MA = 1000.0;
const float VIB_WARN = 2.0, VIB_FAULT = 4.0;

DHT dht(DHT_PIN, DHT_TYPE);
Adafruit_INA219 ina219;
Adafruit_MPU6050 mpu;
LiquidCrystal_I2C lcd(0x27, 16, 2);
WiFiClient client;

float tempC = NAN, humidity = NAN, voltage = NAN, currentMA = NAN;
float powerMW = NAN, vibration = NAN;
bool inaOK = false, mpuOK = false, dhtOK = false;
int faultCode = 0, alertLevel = 0;
String faultText = "NORMAL";

unsigned long sensorTimer = 0, lcdTimer = 0, cloudTimer = 0;
unsigned long wifiTimer = 0;

void indicators() {
  digitalWrite(GREEN_LED, alertLevel == 0);
  digitalWrite(YELLOW_LED, alertLevel == 1);
  digitalWrite(RED_LED, alertLevel == 2);
  digitalWrite(BUZZER, alertLevel == 2);
}

void checkFaults() {
  faultCode = 0; alertLevel = 0; faultText = "NORMAL";
  if (!dhtOK || !inaOK || !mpuOK || isnan(tempC) || isnan(humidity) ||
      isnan(voltage) || isnan(currentMA) || isnan(vibration)) {
    faultCode = 5; alertLevel = 2; faultText = "SENSOR FAULT";
  } else if (tempC >= TEMP_FAULT) {
    faultCode = 2; alertLevel = 2; faultText = "HIGH TEMP";
  } else if (currentMA >= CURRENT_FAULT_MA) {
    faultCode = 3; alertLevel = 2; faultText = "OVER CURRENT";
  } else if (vibration >= VIB_FAULT) {
    faultCode = 4; alertLevel = 2; faultText = "HIGH VIBRATION";
  } else if (tempC >= TEMP_WARN || currentMA >= CURRENT_WARN_MA ||
             vibration >= VIB_WARN) {
    faultCode = 1; alertLevel = 1; faultText = "WARNING";
  }
  indicators();
}

void readSensors() {
  float t = dht.readTemperature(), h = dht.readHumidity();
  dhtOK = !isnan(t) && !isnan(h);
  if (dhtOK) { tempC = t; humidity = h; }

  if (inaOK) {
    voltage = ina219.getBusVoltage_V();
    currentMA = ina219.getCurrent_mA();
    powerMW = ina219.getPower_mW();
    if (isnan(voltage) || isnan(currentMA) || isnan(powerMW)) inaOK = false;
  }

  if (mpuOK) {
    sensors_event_t a, g, m;
    mpu.getEvent(&a, &g, &m);
    float magnitude = sqrt(a.acceleration.x*a.acceleration.x +
                           a.acceleration.y*a.acceleration.y +
                           a.acceleration.z*a.acceleration.z);
    vibration = fabs(magnitude - 9.80665); // simple vibration index
    if (isnan(vibration)) mpuOK = false;
  }

  checkFaults();
  Serial.printf("T=%.2f C, H=%.1f %%, V=%.2f V, I=%.2f mA, P=%.2f mW, Vib=%.2f, Fault=%d (%s)\\n",
                tempC, humidity, voltage, currentMA, powerMW,
                vibration, faultCode, faultText.c_str());
}

void updateLCD() {
  lcd.clear();
  lcd.setCursor(0, 0);
  if (dhtOK) {
    lcd.print("T:"); lcd.print(tempC, 1);
    lcd.print("C H:"); lcd.print(humidity, 0); lcd.print("%");
  } else lcd.print("DHT SENSOR ERROR");
  lcd.setCursor(0, 1);
  lcd.print(alertLevel == 0 ? "STATUS: NORMAL" : faultText.substring(0, 16));
}

void uploadThingSpeak() {
  if (WiFi.status() != WL_CONNECTED || CHANNEL_ID == 0 ||
      String(WRITE_API_KEY) == "YOUR_WRITE_API_KEY") return;
  ThingSpeak.setField(1, dhtOK ? tempC : 0);
  ThingSpeak.setField(2, dhtOK ? humidity : 0);
  ThingSpeak.setField(3, inaOK ? voltage : 0);
  ThingSpeak.setField(4, inaOK ? currentMA : 0);
  ThingSpeak.setField(5, inaOK ? powerMW : 0);
  ThingSpeak.setField(6, mpuOK ? vibration : 0);
  ThingSpeak.setField(7, faultCode);
  ThingSpeak.setField(8, alertLevel);
  int result = ThingSpeak.writeFields(CHANNEL_ID, WRITE_API_KEY);
  Serial.println(result == 200 ? "ThingSpeak upload OK" : "ThingSpeak upload failed");
}

void setup() {
  Serial.begin(115200);
  pinMode(RED_LED, OUTPUT); pinMode(GREEN_LED, OUTPUT);
  pinMode(YELLOW_LED, OUTPUT); pinMode(BUZZER, OUTPUT);
  indicators();

  Wire.begin(21, 22);
  dht.begin();
  lcd.init(); lcd.backlight();
  lcd.setCursor(0, 0); lcd.print("Industrial IoT");
  lcd.setCursor(0, 1); lcd.print("Starting...");

  inaOK = ina219.begin();
  mpuOK = mpu.begin();
  if (mpuOK) {
    mpu.setAccelerometerRange(MPU6050_RANGE_4_G);
    mpu.setGyroRange(MPU6050_RANGE_500_DEG);
    mpu.setFilterBandwidth(MPU6050_BAND_21_HZ);
  }
  if (!inaOK) Serial.println("INA219 not found; check I2C wiring.");
  if (!mpuOK) Serial.println("MPU6050 not found; check I2C wiring.");

  ThingSpeak.begin(client);
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.println("Monitoring started. No automatic recovery is implemented.");
}

void loop() {
  unsigned long now = millis();

  if (WiFi.status() != WL_CONNECTED && now - wifiTimer >= 10000) {
    wifiTimer = now;
    WiFi.disconnect();
    WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  }
  if (now - sensorTimer >= 2000) {
    sensorTimer = now;
    readSensors();
  }
  if (now - lcdTimer >= 1000) {
    lcdTimer = now;
    updateLCD();
  }
  if (now - cloudTimer >= 20000) { // ThingSpeak update interval
    cloudTimer = now;
    uploadThingSpeak();
  }
}
